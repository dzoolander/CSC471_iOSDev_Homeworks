//
//  FavoriteModel.swift
//  DKrebs_MockRemoteIIIHW7
//
//  Created by user165127 on 3/10/20.
//  Copyright © 2020 DePaul University CDM. All rights reserved.
//

import Foundation

var channel = 3
var favName = "Sci"
var favSegment = 0
var favChannels = [3, 5, 45, 56]
